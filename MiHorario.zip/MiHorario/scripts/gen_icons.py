#!/usr/bin/env python3
"""Genera los vector drawables del catálogo de iconos de Mi Horario.
Iconos simples, propios (no trazados de otras librerías), estilo plano monocromo
24x24, para evitar cualquier problema de derechos de autor y mantener consistencia visual.
"""
import os

OUT_DIR = os.path.join(os.path.dirname(__file__), "..", "app", "src", "main", "res", "drawable")
os.makedirs(OUT_DIR, exist_ok=True)

TEMPLATE = """<?xml version="1.0" encoding="utf-8"?>
<vector xmlns:android="http://schemas.android.com/apk/res/android"
    android:width="24dp"
    android:height="24dp"
    android:viewportWidth="24"
    android:viewportHeight="24">
{paths}
</vector>
"""

PATH_TEMPLATE = '    <path android:fillColor="{color}" android:pathData="{data}" />'

# key -> list of (color, pathData)
ICONS = {
    "ic_ejercicio": [("#4A4A4A", "M13,4 m-2,0 a2,2 0 1,0 4,0 a2,2 0 1,0 -4,0")],
    "ic_meditacion": [("#4A4A4A", "M12,3 m-2,0 a2,2 0 1,0 4,0 a2,2 0 1,0 -4,0")],
    "ic_negocio": [("#4A4A4A", "M4,8 h16 v11 a1,1 0 0 1 -1,1 h-14 a1,1 0 0 1 -1,-1 z")],
    "ic_tienda": [("#4A4A4A", "M3,9 l1,-5 h16 l1,5 z"), ("#4A4A4A", "M4,10 h16 v9 a1,1 0 0 1 -1,1 h-14 a1,1 0 0 1 -1,-1 z")],
    "ic_comida": [("#4A4A4A", "M6,2 v9 a1,1 0 0 0 2,0 v-9 h1 v9 a1,1 0 0 0 2,0 v-9 h1 v10 a2,2 0 0 1 -2,2 v7 h-2 v-7 a2,2 0 0 1 -2,-2 z")],
    "ic_dinero": [("#4A4A4A", "M12,2 m-9,0 a9,9 0 1,0 18,0 a9,9 0 1,0 -18,0")],
    "ic_ahorro": [("#4A4A4A", "M4,10 q0,-4 5,-5 l1,-2 h3 l1,2 h1 q3,0 3,3 v2 l2,2 v2 h-2 v3 h-3 v-3 h-6 v3 h-3 v-4 q-2,-1 -2,-3 z")],
    "ic_salud": [("#4A4A4A", "M12,21 C7,17 3,13.5 3,9.5 3,6.5 5.5,4 8.5,4 10,4 11.3,4.7 12,5.8 12.7,4.7 14,4 15.5,4 18.5,4 21,6.5 21,9.5 21,13.5 17,17 12,21 z")],
    "ic_familia": [("#4A4A4A", "M12,3 L21,10 h-2 v9 h-14 v-9 h-2 z")],
    "ic_mascota": [("#4A4A4A", "M7,6 m-2,0 a2,2 0 1,0 4,0 a2,2 0 1,0 -4,0"), ("#4A4A4A", "M17,6 m-2,0 a2,2 0 1,0 4,0 a2,2 0 1,0 -4,0"), ("#4A4A4A", "M12,20 q-6,0 -6,-5 a6,5 0 0 1 12,0 q0,5 -6,5 z")],
    "ic_lectura": [("#4A4A4A", "M4,4 h7 v16 h-7 z"), ("#4A4A4A", "M13,4 h7 v16 h-7 z")],
    "ic_escritura": [("#4A4A4A", "M4,17 l1,-4 l11,-11 l3,3 l-11,11 z M18,3 l3,3 l-2,2 l-3,-3 z")],
    "ic_video": [("#4A4A4A", "M3,7 h14 v10 h-14 z"), ("#4A4A4A", "M17,10 l4,-3 v10 l-4,-3 z")],
    "ic_redes": [("#4A4A4A", "M12,2 a10,10 0 1 0 0.001,0 M2,12 h20 M12,2 a15,10 0 0 1 0,20 a15,10 0 0 1 0,-20")],
    "ic_marketing": [("#4A4A4A", "M3,10 v4 h4 l6,4 v-16 l-6,4 z"), ("#4A4A4A", "M19,9 a5,5 0 0 1 0,6")],
    "ic_limpieza": [("#4A4A4A", "M11,2 h2 v9 h-2 z"), ("#4A4A4A", "M7,11 h10 l-1.5,10 h-7 z")],
    "ic_iglesia": [("#4A4A4A", "M11,2 h2 v3 h2 v2 h-2 v2 h4 l2,4 h-3 v9 h-12 v-9 h-3 l2,-4 h4 v-2 h-2 v-2 h2 z")],
    "ic_musica": [("#4A4A4A", "M9,3 v12.2 a3,3 0 1 0 2,2.8 v-9 l8,-2 v7.2 a3,3 0 1 0 2,2.8 v-14 z")],
    "ic_deporte": [("#4A4A4A", "M12,2 a10,10 0 1 0 0.001,0 M2,12 h20 M12,2 v20 M4.9,4.9 l14.2,14.2 M19.1,4.9 l-14.2,14.2")],
    "ic_descanso": [("#4A4A4A", "M20,14.5 A8.5,8.5 0 1 1 9.5,4 A7,7 0 0 0 20,14.5 z")],
    "ic_cuidado_personal": [("#4A4A4A", "M12,2 q5,6 5,10 a5,5 0 1 1 -10,0 q0,-4 5,-10 z")],
    "ic_estudio": [("#4A4A4A", "M12,3 l10,4 l-10,4 l-10,-4 z"), ("#4A4A4A", "M6,11 v5 q6,4 12,0 v-5")],
    "ic_impuestos": [("#4A4A4A", "M6,2 h9 l3,3 v17 h-12 z"), ("#4A4A4A", "M9,9 h6 M9,13 h6 M9,17 h4")],
    "ic_telefono": [("#4A4A4A", "M6.6,10.8 q2.5,4.5 6.6,6.6 l2.2,-2.2 q0.6,-0.6 1.4,-0.3 l3.6,1.2 q0.8,0.3 0.8,1.1 v3.4 q0,1 -1,1 Q9,21.6 3,10.6 Q3,9.6 4,9.6 h3.4 q0.8,0 1.1,0.8 l1.2,3.6 q0.3,0.8 -0.3,1.4 z")],
    "ic_email": [("#4A4A4A", "M3,6 h18 v12 h-18 z"), ("#4A4A4A", "M3,6 l9,7 l9,-7")],
    "ic_tarea": [("#4A4A4A", "M4,4 h16 v16 h-16 z"), ("#4A4A4A", "M7,12 l3,3 l7,-7")],
    "ic_alarma": [("#4A4A4A", "M12,22 a8,8 0 1 0 0.001,0"), ("#4A4A4A", "M12,8 v5 l4,2")],
    "ic_computadora": [("#4A4A4A", "M3,4 h18 v12 h-18 z"), ("#4A4A4A", "M8,19 h8 l1,2 h-10 z")],
    "ic_avion": [("#4A4A4A", "M2,16 l20,-6 l-8,6 l2,6 l-3,-1 l-2,-5 l-5,3 v-3 z")],
    "ic_generico": [("#4A4A4A", "M12,2 l2.6,7.9 h8.4 l-6.8,4.9 l2.6,7.9 l-6.8,-4.9 l-6.8,4.9 l2.6,-7.9 l-6.8,-4.9 h8.4 z")],
}

for name, paths in ICONS.items():
    body = "\n".join(PATH_TEMPLATE.format(color=c, data=d) for c, d in paths)
    xml = TEMPLATE.format(paths=body)
    with open(os.path.join(OUT_DIR, f"{name}.xml"), "w") as f:
        f.write(xml)

print(f"Generados {len(ICONS)} iconos en {os.path.abspath(OUT_DIR)}")
