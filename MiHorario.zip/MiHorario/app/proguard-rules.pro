# Reglas de ProGuard/R8. Minificación desactivada en debug y release por defecto.
# Agrega reglas aquí si activas isMinifyEnabled = true en el futuro.
-keep class com.maury.horario.data.** { *; }
