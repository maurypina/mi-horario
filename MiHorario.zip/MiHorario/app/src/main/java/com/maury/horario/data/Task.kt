package com.maury.horario.data

import androidx.room.Entity
import androidx.room.PrimaryKey

/**
 * Una tarea del horario. Puede repetirse cada semana en un día específico (dayOfWeek,
 * 1=Lunes..7=Domingo) o cada mes en un día del mes (dayOfMonth), como TSS o DGII.
 */
@Entity(tableName = "tasks")
data class Task(
    @PrimaryKey(autoGenerate = true) val id: Long = 0,
    val title: String,
    val category: Category = Category.OTRO,
    val iconType: IconType = IconType.BUNDLED,
    // Si iconType == BUNDLED: clave del catálogo (ver IconCatalog.kt)
    // Si iconType == CUSTOM: URI (string) de la imagen elegida en la galería
    val iconKey: String,
    val recurrence: Recurrence = Recurrence.WEEKLY,
    val dayOfWeek: Int? = null,   // 1..7 (ISO: Lunes=1 .. Domingo=7)
    val dayOfMonth: Int? = null,  // 1..31
    val startHour: Int,           // 0..23
    val startMinute: Int = 0,
    val endHour: Int,             // 0..23 (puede ser menor que startHour si cruza medianoche)
    val alarmEnabled: Boolean = true,
    val reminderOffsetMinutes: Int = 0,
    val active: Boolean = true,
    val notes: String = ""
)
