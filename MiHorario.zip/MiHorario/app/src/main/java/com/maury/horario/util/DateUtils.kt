package com.maury.horario.util

import com.maury.horario.data.Recurrence
import com.maury.horario.data.Task
import java.time.LocalDate
import java.time.LocalDateTime
import java.time.YearMonth

object DateUtils {

    /** Tareas que aplican en una fecha concreta (según sea semanal o mensual). */
    fun tasksForDate(all: List<Task>, date: LocalDate): List<Task> = all.filter { task ->
        when (task.recurrence) {
            Recurrence.WEEKLY -> task.dayOfWeek == date.dayOfWeek.value
            Recurrence.MONTHLY -> task.dayOfMonth == date.dayOfMonth
        }
    }

    /**
     * Calcula la próxima vez (fecha+hora) que debe sonar la alarma de una tarea,
     * estrictamente después de [from]. Sirve tanto para programar la primera alarma
     * como para reprogramar la siguiente ocurrencia tras cada disparo.
     */
    fun nextOccurrence(task: Task, from: LocalDateTime): LocalDateTime {
        return when (task.recurrence) {
            Recurrence.WEEKLY -> nextWeeklyOccurrence(task, from)
            Recurrence.MONTHLY -> nextMonthlyOccurrence(task, from)
        }
    }

    private fun candidateAt(date: LocalDate, task: Task): LocalDateTime =
        LocalDateTime.of(date, java.time.LocalTime.of(task.startHour, task.startMinute))

    private fun nextWeeklyOccurrence(task: Task, from: LocalDateTime): LocalDateTime {
        val targetDow = task.dayOfWeek ?: 1
        var date = from.toLocalDate()
        var candidate = candidateAt(date, task)
        // Avanza día a día hasta encontrar el próximo día de semana correcto con hora futura.
        for (i in 0..7) {
            if (date.dayOfWeek.value == targetDow && candidate.isAfter(from)) {
                return candidate
            }
            date = date.plusDays(1)
            candidate = candidateAt(date, task)
        }
        return candidate
    }

    private fun nextMonthlyOccurrence(task: Task, from: LocalDateTime): LocalDateTime {
        val targetDom = task.dayOfMonth ?: 1
        var yearMonth = YearMonth.from(from.toLocalDate())
        repeat(24) { // busca hasta 2 años adelante como límite de seguridad
            val lastDay = yearMonth.lengthOfMonth()
            val dom = targetDom.coerceAtMost(lastDay)
            val candidate = candidateAt(yearMonth.atDay(dom), task)
            if (candidate.isAfter(from)) return candidate
            yearMonth = yearMonth.plusMonths(1)
        }
        return from.plusDays(1)
    }
}
