package com.maury.horario.ui.week

import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.LazyRow
import androidx.compose.foundation.lazy.items
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.Add
import androidx.compose.material3.FilterChip
import androidx.compose.material3.FloatingActionButton
import androidx.compose.material3.Icon
import androidx.compose.material3.Scaffold
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.unit.dp
import androidx.lifecycle.compose.collectAsStateWithLifecycle
import com.maury.horario.data.LogStatus
import com.maury.horario.data.Recurrence
import com.maury.horario.data.Task
import com.maury.horario.ui.HorarioViewModel
import com.maury.horario.ui.today.TaskRow

private val diaLabels = listOf("L", "M", "X", "J", "V", "S", "D")
private val diaNombres = listOf(
    "Lunes", "Martes", "Miércoles", "Jueves", "Viernes", "Sábado", "Domingo"
)

/** null en dayOfWeek representa la pestaña "Mensual". */
@Composable
fun WeekScreen(
    viewModel: HorarioViewModel,
    onAddTask: (Int?) -> Unit,
    onEditTask: (Task) -> Unit
) {
    var selectedDay by remember { mutableStateOf<Int?>(1) }
    val allTasks by viewModel.tasks.collectAsStateWithLifecycle()

    val tasksShown = remember(allTasks, selectedDay) {
        if (selectedDay != null) {
            allTasks.filter { it.recurrence == Recurrence.WEEKLY && it.dayOfWeek == selectedDay }
                .sortedBy { it.startHour }
        } else {
            allTasks.filter { it.recurrence == Recurrence.MONTHLY }
                .sortedBy { it.dayOfMonth }
        }
    }

    Scaffold(
        floatingActionButton = {
            FloatingActionButton(onClick = { onAddTask(selectedDay) }) {
                Icon(Icons.Filled.Add, contentDescription = "Agregar tarea")
            }
        }
    ) { padding ->
        Column(modifier = Modifier.fillMaxSize().padding(padding)) {
            LazyRow(modifier = Modifier.fillMaxWidth().padding(8.dp)) {
                items(7) { index ->
                    val dow = index + 1
                    FilterChip(
                        selected = selectedDay == dow,
                        onClick = { selectedDay = dow },
                        label = { Text(diaLabels[index]) },
                        modifier = Modifier.padding(horizontal = 2.dp)
                    )
                }
                item {
                    FilterChip(
                        selected = selectedDay == null,
                        onClick = { selectedDay = null },
                        label = { Text("Mensual") },
                        modifier = Modifier.padding(horizontal = 2.dp)
                    )
                }
            }

            Text(
                text = if (selectedDay != null) diaNombres[selectedDay!! - 1] else "Tareas mensuales (ej. TSS, DGII)",
                modifier = Modifier.padding(horizontal = 12.dp, vertical = 4.dp)
            )

            if (tasksShown.isEmpty()) {
                Box(modifier = Modifier.fillMaxSize(), contentAlignment = Alignment.Center) {
                    Text("No hay tareas aquí todavía. Toca + para crear una.")
                }
            } else {
                LazyColumn(modifier = Modifier.fillMaxSize().padding(horizontal = 12.dp)) {
                    items(tasksShown, key = { it.id }) { task ->
                        if (selectedDay != null) {
                            TaskRow(
                                task = task,
                                status = LogStatus.PENDING,
                                onClick = { onEditTask(task) },
                                onSetStatus = { /* la plantilla no marca hecho/no hecho, eso es en "Hoy" */ }
                            )
                        } else {
                            MonthlyTaskRow(task = task, onClick = { onEditTask(task) })
                        }
                    }
                }
            }
        }
    }
}

@Composable
private fun MonthlyTaskRow(task: Task, onClick: () -> Unit) {
    androidx.compose.material3.Card(
        modifier = Modifier.fillMaxWidth().padding(vertical = 4.dp),
        onClick = onClick
    ) {
        Column(modifier = Modifier.padding(10.dp)) {
            Text("Día ${task.dayOfMonth} de cada mes · ${String.format("%02d:00", task.startHour)}")
            Text(task.title)
        }
    }
}
