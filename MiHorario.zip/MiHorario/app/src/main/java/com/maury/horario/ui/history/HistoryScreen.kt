package com.maury.horario.ui.history

import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.material3.Card
import androidx.compose.material3.Divider
import androidx.compose.material3.LinearProgressIndicator
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.runtime.getValue
import androidx.compose.runtime.remember
import androidx.compose.ui.Modifier
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.lifecycle.compose.collectAsStateWithLifecycle
import com.maury.horario.data.Category
import com.maury.horario.data.LogStatus
import com.maury.horario.ui.HorarioViewModel
import com.maury.horario.util.DateUtils
import java.time.LocalDate
import java.time.format.DateTimeFormatter
import java.util.Locale

@Composable
fun HistoryScreen(viewModel: HorarioViewModel) {
    val today = LocalDate.now()
    val from = today.minusDays(13)

    val allTasks by viewModel.tasks.collectAsStateWithLifecycle()
    val logs by viewModel.logsRange(from, today).collectAsStateWithLifecycle(initialValue = emptyList())

    val tasksById = remember(allTasks) { allTasks.associateBy { it.id } }
    val logsByDay = remember(logs) { logs.groupBy { it.epochDay } }

    val categoryDoneCounts = remember(logs, allTasks) {
        val counts = mutableMapOf<Category, Int>()
        logs.filter { it.status == LogStatus.DONE }.forEach { log ->
            val cat = tasksById[log.taskId]?.category ?: Category.OTRO
            counts[cat] = (counts[cat] ?: 0) + 1
        }
        counts
    }

    LazyColumn(modifier = Modifier.fillMaxSize().padding(12.dp)) {
        item {
            Text("Balance de tus áreas (Manifiesto) · últimos 14 días", fontWeight = FontWeight.Bold)
            Column(modifier = Modifier.padding(vertical = 8.dp)) {
                val maxCount = (categoryDoneCounts.values.maxOrNull() ?: 0).coerceAtLeast(1)
                Category.values().forEach { cat ->
                    val count = categoryDoneCounts[cat] ?: 0
                    if (count > 0 || cat != Category.OTRO) {
                        Row(
                            modifier = Modifier.fillMaxWidth().padding(vertical = 3.dp),
                            verticalAlignment = androidx.compose.ui.Alignment.CenterVertically
                        ) {
                            Text(cat.etiqueta, modifier = Modifier.padding(end = 8.dp))
                        }
                        LinearProgressIndicator(
                            progress = count / maxCount.toFloat(),
                            modifier = Modifier.fillMaxWidth().padding(bottom = 6.dp)
                        )
                    }
                }
            }
            Divider(modifier = Modifier.padding(vertical = 8.dp))
            Text("Últimos 14 días", fontWeight = FontWeight.Bold, modifier = Modifier.padding(bottom = 8.dp))
        }

        items((0..13).map { today.minusDays(it.toLong()) }) { date ->
            val scheduled = DateUtils.tasksForDate(allTasks, date)
            val dayLogs = logsByDay[date.toEpochDay()].orEmpty()
            val done = dayLogs.count { it.status == LogStatus.DONE }
            val missed = dayLogs.count { it.status == LogStatus.MISSED }
            val total = scheduled.size

            Card(modifier = Modifier.fillMaxWidth().padding(vertical = 4.dp)) {
                Column(modifier = Modifier.padding(10.dp)) {
                    val formatter = DateTimeFormatter.ofPattern("EEEE d MMM", Locale("es", "ES"))
                    Text(
                        date.format(formatter).replaceFirstChar { it.uppercase() },
                        fontWeight = FontWeight.Medium
                    )
                    Text(
                        "✅ $done hechas   ❌ $missed no hechas   de $total programadas",
                        style = MaterialTheme.typography.bodySmall
                    )
                }
            }
        }
    }
}
