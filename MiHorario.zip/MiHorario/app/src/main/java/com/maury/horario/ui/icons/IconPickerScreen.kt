@file:OptIn(androidx.compose.material3.ExperimentalMaterial3Api::class)

package com.maury.horario.ui.icons

import androidx.activity.compose.rememberLauncherForActivityResult
import androidx.activity.result.PickVisualMediaRequest
import androidx.activity.result.contract.ActivityResultContracts
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.lazy.grid.GridCells
import androidx.compose.foundation.lazy.grid.LazyVerticalGrid
import androidx.compose.foundation.lazy.grid.items
import androidx.compose.material3.Button
import androidx.compose.material3.Card
import androidx.compose.material3.Icon
import androidx.compose.material3.Scaffold
import androidx.compose.material3.Text
import androidx.compose.material3.TopAppBar
import androidx.compose.runtime.Composable
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.res.painterResource
import androidx.compose.ui.unit.dp
import com.maury.horario.data.IconType
import com.maury.horario.ui.HorarioViewModel

@Composable
fun IconPickerScreen(
    viewModel: HorarioViewModel,
    onDone: () -> Unit
) {
    val context = LocalContext.current

    val pickMedia = rememberLauncherForActivityResult(
        ActivityResultContracts.PickVisualMedia()
    ) { uri ->
        if (uri != null) {
            viewModel.updateDraft {
                it.copy(iconType = IconType.CUSTOM, iconKey = uri.toString())
            }
            onDone()
        }
    }

    Scaffold(
        topBar = { TopAppBar(title = { Text("Elegir icono") }) }
    ) { padding ->
        Column(modifier = Modifier.fillMaxSize().padding(padding).padding(12.dp)) {
            Button(
                onClick = {
                    pickMedia.launch(
                        PickVisualMediaRequest(ActivityResultContracts.PickVisualMedia.ImageOnly)
                    )
                },
                modifier = Modifier.fillMaxWidth().padding(bottom = 8.dp)
            ) {
                Text("📷 Elegir una imagen de mi galería")
            }

            Text("O elige uno de la galería de iconos:", modifier = Modifier.padding(vertical = 8.dp))

            LazyVerticalGrid(
                columns = GridCells.Fixed(4),
                modifier = Modifier.fillMaxSize()
            ) {
                items(IconCatalog.items, key = { it.key }) { item ->
                    Card(
                        modifier = Modifier.padding(6.dp).size(72.dp),
                        onClick = {
                            viewModel.updateDraft {
                                it.copy(iconType = IconType.BUNDLED, iconKey = item.key)
                            }
                            onDone()
                        }
                    ) {
                        Column(
                            modifier = Modifier.fillMaxSize(),
                            horizontalAlignment = Alignment.CenterHorizontally,
                            verticalArrangement = androidx.compose.foundation.layout.Arrangement.Center
                        ) {
                            Icon(
                                painter = painterResource(id = item.resId),
                                contentDescription = item.label,
                                modifier = Modifier.size(28.dp)
                            )
                            Text(
                                text = item.label,
                                style = androidx.compose.material3.MaterialTheme.typography.labelSmall,
                                maxLines = 1
                            )
                        }
                    }
                }
            }
        }
    }
}
