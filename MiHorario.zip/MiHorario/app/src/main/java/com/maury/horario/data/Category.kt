package com.maury.horario.data

/**
 * Áreas de vida del "Manifiesto" del usuario. Cada tarea pertenece a una,
 * lo que permite luego ver un resumen de balance entre áreas en el Historial.
 */
enum class Category(val etiqueta: String) {
    DINERO("Dinero/Finanzas"),
    RELACION("Relación"),
    RECREACION("Recreación"),
    FAMILIA("Familia"),
    SALUD("Salud"),
    SERVICIO("Servicio comunitario"),
    PROFESION("Profesión"),
    OTRO("Otro")
}

enum class Recurrence {
    WEEKLY,
    MONTHLY
}

enum class IconType {
    BUNDLED,
    CUSTOM
}

enum class LogStatus {
    PENDING,
    DONE,
    MISSED
}
