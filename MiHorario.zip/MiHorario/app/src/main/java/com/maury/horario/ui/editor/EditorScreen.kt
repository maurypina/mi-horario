@file:OptIn(androidx.compose.material3.ExperimentalMaterial3Api::class)

package com.maury.horario.ui.editor

import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.lazy.LazyRow
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.verticalScroll
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.Delete
import androidx.compose.material3.Button
import androidx.compose.material3.Card
import androidx.compose.material3.DropdownMenu
import androidx.compose.material3.DropdownMenuItem
import androidx.compose.material3.ExposedDropdownMenuBox
import androidx.compose.material3.ExposedDropdownMenuDefaults
import androidx.compose.material3.FilterChip
import androidx.compose.material3.Icon
import androidx.compose.material3.IconButton
import androidx.compose.material3.OutlinedButton
import androidx.compose.material3.OutlinedTextField
import androidx.compose.material3.Scaffold
import androidx.compose.material3.Switch
import androidx.compose.material3.Text
import androidx.compose.material3.TextButton
import androidx.compose.material3.TopAppBar
import androidx.compose.runtime.Composable
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.res.painterResource
import androidx.compose.ui.unit.dp
import androidx.lifecycle.compose.collectAsStateWithLifecycle
import com.maury.horario.data.Category
import com.maury.horario.data.IconType
import com.maury.horario.data.Recurrence
import com.maury.horario.ui.HorarioViewModel
import com.maury.horario.ui.icons.IconCatalog

private val diaLabels = listOf("Lunes", "Martes", "Miércoles", "Jueves", "Viernes", "Sábado", "Domingo")

@Composable
fun EditorScreen(
    viewModel: HorarioViewModel,
    onDone: () -> Unit,
    onPickIcon: () -> Unit
) {
    val draft by viewModel.draft.collectAsStateWithLifecycle()

    Scaffold(
        topBar = {
            TopAppBar(
                title = { Text(if (draft.id == 0L) "Nueva tarea" else "Editar tarea") },
                actions = {
                    if (draft.id != 0L) {
                        IconButton(onClick = {
                            viewModel.deleteTask(draft.toTask(), onDone)
                        }) {
                            Icon(Icons.Filled.Delete, contentDescription = "Eliminar")
                        }
                    }
                }
            )
        }
    ) { padding ->
        Column(
            modifier = Modifier
                .fillMaxSize()
                .padding(padding)
                .padding(16.dp)
                .verticalScroll(rememberScrollState())
        ) {
            OutlinedTextField(
                value = draft.title,
                onValueChange = { v -> viewModel.updateDraft { it.copy(title = v) } },
                label = { Text("Nombre de la tarea") },
                modifier = Modifier.fillMaxWidth()
            )

            Box(modifier = Modifier.padding(top = 12.dp)) {
                IconPreviewButton(iconType = draft.iconType, iconKey = draft.iconKey, onClick = onPickIcon)
            }

            Text("Área de vida", modifier = Modifier.padding(top = 16.dp, bottom = 4.dp))
            CategoryDropdown(
                selected = draft.category,
                onSelect = { cat -> viewModel.updateDraft { it.copy(category = cat) } }
            )

            Text("Repetición", modifier = Modifier.padding(top = 16.dp, bottom = 4.dp))
            Row {
                FilterChip(
                    selected = draft.recurrence == Recurrence.WEEKLY,
                    onClick = { viewModel.updateDraft { it.copy(recurrence = Recurrence.WEEKLY) } },
                    label = { Text("Cada semana") },
                    modifier = Modifier.padding(end = 8.dp)
                )
                FilterChip(
                    selected = draft.recurrence == Recurrence.MONTHLY,
                    onClick = { viewModel.updateDraft { it.copy(recurrence = Recurrence.MONTHLY) } },
                    label = { Text("Cada mes") }
                )
            }

            if (draft.recurrence == Recurrence.WEEKLY) {
                Text("Día de la semana", modifier = Modifier.padding(top = 16.dp, bottom = 4.dp))
                LazyRow {
                    items(7) { index ->
                        val dow = index + 1
                        FilterChip(
                            selected = draft.dayOfWeek == dow,
                            onClick = { viewModel.updateDraft { it.copy(dayOfWeek = dow) } },
                            label = { Text(diaLabels[index].take(2)) },
                            modifier = Modifier.padding(end = 6.dp)
                        )
                    }
                }
            } else {
                Text("Día del mes", modifier = Modifier.padding(top = 16.dp, bottom = 4.dp))
                NumberStepper(
                    value = draft.dayOfMonth,
                    range = 1..31,
                    onChange = { v -> viewModel.updateDraft { it.copy(dayOfMonth = v) } }
                )
            }

            Text("Horario", modifier = Modifier.padding(top = 16.dp, bottom = 4.dp))
            Row(verticalAlignment = Alignment.CenterVertically) {
                Text("De:")
                NumberStepper(
                    value = draft.startHour,
                    range = 0..23,
                    onChange = { v -> viewModel.updateDraft { it.copy(startHour = v) } },
                    suffix = ":00"
                )
                Text("a:", modifier = Modifier.padding(start = 12.dp))
                NumberStepper(
                    value = draft.endHour,
                    range = 0..23,
                    onChange = { v -> viewModel.updateDraft { it.copy(endHour = v) } },
                    suffix = ":00"
                )
            }

            Row(
                modifier = Modifier.fillMaxWidth().padding(top = 16.dp),
                horizontalArrangement = Arrangement.SpaceBetween,
                verticalAlignment = Alignment.CenterVertically
            ) {
                Text("Sonar alarma y notificación")
                Switch(
                    checked = draft.alarmEnabled,
                    onCheckedChange = { v -> viewModel.updateDraft { it.copy(alarmEnabled = v) } }
                )
            }

            Button(
                onClick = { viewModel.saveDraft(onDone) },
                modifier = Modifier.fillMaxWidth().padding(top = 24.dp)
            ) {
                Text("Guardar")
            }
            TextButton(onClick = onDone, modifier = Modifier.fillMaxWidth()) {
                Text("Cancelar")
            }
        }
    }
}

@Composable
private fun IconPreviewButton(iconType: IconType, iconKey: String, onClick: () -> Unit) {
    OutlinedButton(onClick = onClick) {
        if (iconType == IconType.CUSTOM) {
            com.maury.horario.ui.icons.CustomIconImage(uriString = iconKey, modifier = Modifier.size(28.dp))
        } else {
            Icon(
                painter = painterResource(id = IconCatalog.resFor(iconKey)),
                contentDescription = null,
                modifier = Modifier.size(28.dp)
            )
        }
        Text(text = "  Elegir icono", modifier = Modifier.padding(start = 8.dp))
    }
}

@Composable
private fun CategoryDropdown(selected: Category, onSelect: (Category) -> Unit) {
    var expanded by remember { mutableStateOf(false) }
    ExposedDropdownMenuBox(expanded = expanded, onExpandedChange = { expanded = it }) {
        OutlinedTextField(
            value = selected.etiqueta,
            onValueChange = {},
            readOnly = true,
            trailingIcon = { ExposedDropdownMenuDefaults.TrailingIcon(expanded = expanded) },
            modifier = Modifier.fillMaxWidth().menuAnchor()
        )
        DropdownMenu(expanded = expanded, onDismissRequest = { expanded = false }) {
            Category.values().forEach { cat ->
                DropdownMenuItem(
                    text = { Text(cat.etiqueta) },
                    onClick = { onSelect(cat); expanded = false }
                )
            }
        }
    }
}

@Composable
private fun NumberStepper(value: Int, range: IntRange, onChange: (Int) -> Unit, suffix: String = "") {
    Row(verticalAlignment = Alignment.CenterVertically, modifier = Modifier.padding(horizontal = 4.dp)) {
        IconButton(onClick = { if (value - 1 >= range.first) onChange(value - 1) else onChange(range.last) }) {
            Text("−")
        }
        Text("$value$suffix", modifier = Modifier.padding(horizontal = 4.dp))
        IconButton(onClick = { if (value + 1 <= range.last) onChange(value + 1) else onChange(range.first) }) {
            Text("+")
        }
    }
}
