package com.maury.horario.notification

import android.app.NotificationChannel
import android.app.NotificationManager
import android.app.PendingIntent
import android.content.Context
import android.content.Intent
import androidx.core.app.NotificationCompat
import com.maury.horario.MainActivity
import com.maury.horario.R
import com.maury.horario.data.IconType
import com.maury.horario.data.Task
import com.maury.horario.ui.icons.IconCatalog

const val CHANNEL_ID = "tareas_horario"
const val EXTRA_ACTION = "extra_action"
const val EXTRA_EPOCH_DAY = "extra_epoch_day"
const val ACTION_DONE = "com.maury.horario.ACTION_DONE"
const val ACTION_MISSED = "com.maury.horario.ACTION_MISSED"

object NotificationHelper {

    fun ensureChannel(context: Context) {
        val manager = context.getSystemService(Context.NOTIFICATION_SERVICE) as NotificationManager
        val channel = NotificationChannel(
            CHANNEL_ID,
            "Recordatorios de tareas",
            NotificationManager.IMPORTANCE_HIGH
        ).apply {
            description = "Alarmas de tu horario diario"
            enableVibration(true)
        }
        manager.createNotificationChannel(channel)
    }

    fun showTaskNotification(context: Context, task: Task) {
        val epochDay = java.time.LocalDate.now().toEpochDay()

        val contentIntent = PendingIntent.getActivity(
            context, task.id.toInt(),
            Intent(context, MainActivity::class.java),
            PendingIntent.FLAG_UPDATE_CURRENT or PendingIntent.FLAG_IMMUTABLE
        )

        val doneIntent = actionPendingIntent(context, task.id, epochDay, ACTION_DONE, requestCodeOffset = 1)
        val missedIntent = actionPendingIntent(context, task.id, epochDay, ACTION_MISSED, requestCodeOffset = 2)

        val iconRes = if (task.iconType == IconType.BUNDLED) IconCatalog.resFor(task.iconKey) else R.drawable.ic_tarea

        val timeRange = String.format("%02d:00 - %02d:00", task.startHour, task.endHour)
        val notification = NotificationCompat.Builder(context, CHANNEL_ID)
            .setSmallIcon(R.drawable.ic_alarma)
            .setLargeIcon(com.maury.horario.util.BitmapUtils.drawableToBitmap(context, iconRes))
            .setContentTitle(task.title)
            .setContentText("Hora de: $timeRange")
            .setPriority(NotificationCompat.PRIORITY_HIGH)
            .setCategory(NotificationCompat.CATEGORY_ALARM)
            .setAutoCancel(true)
            .setContentIntent(contentIntent)
            .addAction(0, "✅ Hecho", doneIntent)
            .addAction(0, "❌ No hecho", missedIntent)
            .build()

        val manager = context.getSystemService(Context.NOTIFICATION_SERVICE) as NotificationManager
        manager.notify(task.id.toInt(), notification)
    }

    private fun actionPendingIntent(
        context: Context,
        taskId: Long,
        epochDay: Long,
        action: String,
        requestCodeOffset: Int
    ): PendingIntent {
        val intent = Intent(context, NotificationActionReceiver::class.java).apply {
            this.action = action
            putExtra(com.maury.horario.alarm.EXTRA_TASK_ID, taskId)
            putExtra(EXTRA_EPOCH_DAY, epochDay)
        }
        val requestCode = (taskId.toInt() * 10) + requestCodeOffset
        return PendingIntent.getBroadcast(
            context, requestCode, intent,
            PendingIntent.FLAG_UPDATE_CURRENT or PendingIntent.FLAG_IMMUTABLE
        )
    }
}
