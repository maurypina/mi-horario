package com.maury.horario.data

import android.content.Context
import com.maury.horario.alarm.AlarmScheduler
import kotlinx.coroutines.flow.Flow
import java.time.LocalDate

/**
 * Punto único para leer/escribir tareas y su historial, y mantener las alarmas
 * del sistema sincronizadas cada vez que una tarea cambia.
 */
class TaskRepository(
    private val context: Context,
    private val taskDao: TaskDao,
    private val taskLogDao: TaskLogDao
) {
    fun observeAllTasks(): Flow<List<Task>> = taskDao.observeAll()

    fun observeLogsForDay(date: LocalDate): Flow<List<TaskLog>> =
        taskLogDao.observeForDay(date.toEpochDay())

    fun observeLogsRange(from: LocalDate, to: LocalDate): Flow<List<TaskLog>> =
        taskLogDao.observeRange(from.toEpochDay(), to.toEpochDay())

    suspend fun allTasksOnce(): List<Task> = taskDao.getAllOnce()

    suspend fun getTask(id: Long): Task? = taskDao.getById(id)

    suspend fun saveTask(task: Task): Long {
        val id = if (task.id == 0L) taskDao.insert(task) else {
            taskDao.update(task); task.id
        }
        val saved = task.copy(id = id)
        if (saved.alarmEnabled) {
            AlarmScheduler.scheduleNext(context, saved)
        } else {
            AlarmScheduler.cancel(context, saved.id)
        }
        return id
    }

    suspend fun deleteTask(task: Task) {
        AlarmScheduler.cancel(context, task.id)
        taskLogDao.deleteForTask(task.id)
        taskDao.delete(task)
    }

    suspend fun setStatus(taskId: Long, date: LocalDate, status: LogStatus) {
        val existing = taskLogDao.findLog(taskId, date.toEpochDay())
        val log = (existing ?: TaskLog(taskId = taskId, epochDay = date.toEpochDay()))
            .copy(status = status, updatedAtEpochMillis = System.currentTimeMillis())
        taskLogDao.upsert(log)
    }

    suspend fun rescheduleAllAlarms() {
        taskDao.getAllOnce().filter { it.alarmEnabled }.forEach { task ->
            AlarmScheduler.scheduleNext(context, task)
        }
    }
}
