package com.maury.horario.util

import android.content.Context
import android.graphics.Bitmap
import android.graphics.Canvas
import androidx.core.content.ContextCompat

/**
 * Convierte cualquier drawable (incluidos los vector drawables XML del catálogo
 * de iconos) en un Bitmap, para usarlo como icono grande de notificación.
 * BitmapFactory.decodeResource() NO sirve para vectores, por eso dibujamos manualmente.
 */
object BitmapUtils {
    fun drawableToBitmap(context: Context, resId: Int, sizePx: Int = 128): Bitmap {
        val drawable = ContextCompat.getDrawable(context, resId)
        val bitmap = Bitmap.createBitmap(sizePx, sizePx, Bitmap.Config.ARGB_8888)
        val canvas = Canvas(bitmap)
        drawable?.setBounds(0, 0, canvas.width, canvas.height)
        drawable?.draw(canvas)
        return bitmap
    }
}
