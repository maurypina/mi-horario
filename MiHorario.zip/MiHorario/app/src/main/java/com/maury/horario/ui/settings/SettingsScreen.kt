package com.maury.horario.ui.settings

import android.app.AlarmManager
import android.content.Context
import android.content.Intent
import android.net.Uri
import android.os.Build
import android.provider.Settings
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.padding
import androidx.compose.material3.Button
import androidx.compose.material3.Card
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.runtime.DisposableEffect
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.ui.Modifier
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.platform.LocalLifecycleOwner
import androidx.compose.ui.unit.dp
import androidx.lifecycle.Lifecycle
import androidx.lifecycle.LifecycleEventObserver
import com.maury.horario.overlay.OverlayPermission
import com.maury.horario.overlay.OverlayService

@Composable
fun SettingsScreen() {
    val context = LocalContext.current
    val lifecycleOwner = LocalLifecycleOwner.current

    var overlayGranted by remember { mutableStateOf(OverlayPermission.hasPermission(context)) }
    var exactAlarmGranted by remember { mutableStateOf(canScheduleExact(context)) }
    var bubbleRunning by remember { mutableStateOf(false) }

    DisposableEffect(lifecycleOwner) {
        val observer = LifecycleEventObserver { _, event ->
            if (event == Lifecycle.Event.ON_RESUME) {
                overlayGranted = OverlayPermission.hasPermission(context)
                exactAlarmGranted = canScheduleExact(context)
            }
        }
        lifecycleOwner.lifecycle.addObserver(observer)
        onDispose { lifecycleOwner.lifecycle.removeObserver(observer) }
    }

    Column(modifier = Modifier.fillMaxSize().padding(16.dp)) {
        Text("Permisos y burbuja flotante", style = androidx.compose.material3.MaterialTheme.typography.titleMedium)

        Card(modifier = Modifier.fillMaxWidth().padding(vertical = 8.dp)) {
            Column(modifier = Modifier.padding(12.dp)) {
                Text(if (overlayGranted) "✅ Permiso de burbuja flotante concedido" else "⬜ Falta permitir la burbuja flotante")
                Text(
                    "Necesario para mostrar tus tareas sobre otras apps (como Facebook Messenger).",
                    style = androidx.compose.material3.MaterialTheme.typography.bodySmall
                )
                Button(
                    onClick = { context.startActivity(OverlayPermission.requestPermissionIntent(context)) },
                    modifier = Modifier.padding(top = 8.dp)
                ) { Text(if (overlayGranted) "Revisar permiso" else "Permitir burbuja flotante") }
            }
        }

        Card(modifier = Modifier.fillMaxWidth().padding(vertical = 8.dp)) {
            Column(modifier = Modifier.padding(12.dp)) {
                Text(if (exactAlarmGranted) "✅ Alarmas exactas permitidas" else "⬜ Falta permitir alarmas exactas")
                Text(
                    "Para que las notificaciones suenen justo a la hora programada, sin retraso.",
                    style = androidx.compose.material3.MaterialTheme.typography.bodySmall
                )
                if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.S) {
                    Button(
                        onClick = {
                            context.startActivity(
                                Intent(Settings.ACTION_REQUEST_SCHEDULE_EXACT_ALARM, Uri.parse("package:${context.packageName}"))
                            )
                        },
                        modifier = Modifier.padding(top = 8.dp)
                    ) { Text("Permitir alarmas exactas") }
                }
            }
        }

        Card(modifier = Modifier.fillMaxWidth().padding(vertical = 8.dp)) {
            Column(modifier = Modifier.padding(12.dp)) {
                Text("Burbuja flotante")
                Text(
                    "Actívala para ver el icono de tu tarea actual flotando sobre cualquier app.",
                    style = androidx.compose.material3.MaterialTheme.typography.bodySmall
                )
                Button(
                    onClick = {
                        if (!overlayGranted) {
                            context.startActivity(OverlayPermission.requestPermissionIntent(context))
                            return@Button
                        }
                        if (bubbleRunning) {
                            OverlayService.stop(context)
                        } else {
                            OverlayService.start(context)
                        }
                        bubbleRunning = !bubbleRunning
                    },
                    modifier = Modifier.padding(top = 8.dp)
                ) { Text(if (bubbleRunning) "Detener burbuja" else "Iniciar burbuja flotante") }
            }
        }
    }
}

private fun canScheduleExact(context: Context): Boolean {
    if (Build.VERSION.SDK_INT < Build.VERSION_CODES.S) return true
    val am = context.getSystemService(Context.ALARM_SERVICE) as AlarmManager
    return am.canScheduleExactAlarms()
}
