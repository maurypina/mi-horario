package com.maury.horario.ui.theme

import androidx.compose.foundation.isSystemInDarkTheme
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.darkColorScheme
import androidx.compose.material3.lightColorScheme
import androidx.compose.runtime.Composable
import androidx.compose.ui.graphics.Color

private val Purple = Color(0xFF6750A4)
private val Teal = Color(0xFF00696B)
private val Green = Color(0xFF2E7D32)

private val LightColors = lightColorScheme(
    primary = Purple,
    secondary = Teal,
    tertiary = Green
)

private val DarkColors = darkColorScheme(
    primary = Purple,
    secondary = Teal,
    tertiary = Green
)

@Composable
fun MiHorarioTheme(
    darkTheme: Boolean = isSystemInDarkTheme(),
    content: @Composable () -> Unit
) {
    val colors = if (darkTheme) DarkColors else LightColors
    MaterialTheme(colorScheme = colors, content = content)
}
