package com.maury.horario.notification

import android.app.NotificationManager
import android.content.BroadcastReceiver
import android.content.Context
import android.content.Intent
import com.maury.horario.HorarioApp
import com.maury.horario.alarm.EXTRA_TASK_ID
import com.maury.horario.data.LogStatus
import kotlinx.coroutines.launch
import java.time.LocalDate

/**
 * Maneja los botones "Hecho" / "No hecho" de la notificación, sin necesidad
 * de abrir la app, y guarda el resultado en el historial.
 */
class NotificationActionReceiver : BroadcastReceiver() {
    override fun onReceive(context: Context, intent: Intent) {
        val taskId = intent.getLongExtra(EXTRA_TASK_ID, -1L)
        val epochDay = intent.getLongExtra(EXTRA_EPOCH_DAY, LocalDate.now().toEpochDay())
        if (taskId < 0) return

        val status = when (intent.action) {
            ACTION_DONE -> LogStatus.DONE
            ACTION_MISSED -> LogStatus.MISSED
            else -> return
        }

        val app = context.applicationContext as HorarioApp
        val pendingResult = goAsync()
        app.appScope.launch {
            try {
                app.database.taskLogDao().upsert(
                    com.maury.horario.data.TaskLog(
                        taskId = taskId,
                        epochDay = epochDay,
                        status = status,
                        updatedAtEpochMillis = System.currentTimeMillis()
                    )
                )
            } finally {
                val manager = context.getSystemService(Context.NOTIFICATION_SERVICE) as NotificationManager
                manager.cancel(taskId.toInt())
                pendingResult.finish()
            }
        }
    }
}
