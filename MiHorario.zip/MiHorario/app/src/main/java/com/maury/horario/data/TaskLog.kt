package com.maury.horario.data

import androidx.room.Entity
import androidx.room.Index
import androidx.room.PrimaryKey

/**
 * Registro de si una tarea concreta (en una fecha concreta) se cumplió o no.
 * epochDay = LocalDate.toEpochDay(), así cada ocurrencia de una tarea recurrente
 * tiene su propia fila de historial. El índice único evita filas duplicadas para
 * la misma tarea+día (OnConflictStrategy.REPLACE se apoya en él).
 */
@Entity(tableName = "task_logs", indices = [Index(value = ["taskId", "epochDay"], unique = true)])
data class TaskLog(
    @PrimaryKey(autoGenerate = true) val id: Long = 0,
    val taskId: Long,
    val epochDay: Long,
    val status: LogStatus = LogStatus.PENDING,
    val updatedAtEpochMillis: Long = 0
)
