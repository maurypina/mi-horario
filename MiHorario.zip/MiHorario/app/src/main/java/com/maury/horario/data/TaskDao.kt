package com.maury.horario.data

import androidx.room.Dao
import androidx.room.Delete
import androidx.room.Insert
import androidx.room.OnConflictStrategy
import androidx.room.Query
import androidx.room.Update
import kotlinx.coroutines.flow.Flow

@Dao
interface TaskDao {

    @Query("SELECT * FROM tasks WHERE active = 1 ORDER BY startHour ASC")
    fun observeAll(): Flow<List<Task>>

    @Query("SELECT * FROM tasks WHERE active = 1 AND recurrence = 'WEEKLY' AND dayOfWeek = :dayOfWeek ORDER BY startHour ASC")
    fun observeForDayOfWeek(dayOfWeek: Int): Flow<List<Task>>

    @Query("SELECT * FROM tasks WHERE active = 1 AND recurrence = 'MONTHLY' AND dayOfMonth = :dayOfMonth ORDER BY startHour ASC")
    fun observeForDayOfMonth(dayOfMonth: Int): Flow<List<Task>>

    @Query("SELECT * FROM tasks WHERE id = :id")
    suspend fun getById(id: Long): Task?

    @Query("SELECT * FROM tasks WHERE active = 1")
    suspend fun getAllOnce(): List<Task>

    @Insert(onConflict = OnConflictStrategy.REPLACE)
    suspend fun insert(task: Task): Long

    @Insert(onConflict = OnConflictStrategy.REPLACE)
    suspend fun insertAll(tasks: List<Task>)

    @Update
    suspend fun update(task: Task)

    @Delete
    suspend fun delete(task: Task)

    @Query("SELECT COUNT(*) FROM tasks")
    suspend fun count(): Int
}
