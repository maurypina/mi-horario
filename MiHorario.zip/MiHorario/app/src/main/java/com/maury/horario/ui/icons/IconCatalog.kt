package com.maury.horario.ui.icons

import com.maury.horario.R
import com.maury.horario.data.Category

data class IconItem(
    val key: String,
    val label: String,
    val resId: Int,
    val categoria: Category
)

/**
 * Catálogo de iconos incluidos con la app. El usuario puede elegir uno de estos
 * o, alternativamente, una imagen personalizada desde su galería (ver IconPickerScreen).
 */
object IconCatalog {

    val items: List<IconItem> = listOf(
        IconItem("ic_ejercicio", "Ejercicio", R.drawable.ic_ejercicio, Category.SALUD),
        IconItem("ic_meditacion", "Meditación", R.drawable.ic_meditacion, Category.SALUD),
        IconItem("ic_deporte", "Deporte", R.drawable.ic_deporte, Category.SALUD),
        IconItem("ic_salud", "Salud", R.drawable.ic_salud, Category.SALUD),
        IconItem("ic_cuidado_personal", "Cuidado personal", R.drawable.ic_cuidado_personal, Category.SALUD),
        IconItem("ic_descanso", "Descanso / Sueño", R.drawable.ic_descanso, Category.SALUD),

        IconItem("ic_negocio", "Negocio", R.drawable.ic_negocio, Category.PROFESION),
        IconItem("ic_tienda", "Tienda / Venta", R.drawable.ic_tienda, Category.PROFESION),
        IconItem("ic_marketing", "Marketing", R.drawable.ic_marketing, Category.PROFESION),
        IconItem("ic_redes", "Redes sociales", R.drawable.ic_redes, Category.PROFESION),
        IconItem("ic_video", "Video / Edición", R.drawable.ic_video, Category.PROFESION),
        IconItem("ic_computadora", "Computadora", R.drawable.ic_computadora, Category.PROFESION),
        IconItem("ic_musica", "Música", R.drawable.ic_musica, Category.PROFESION),
        IconItem("ic_estudio", "Estudio", R.drawable.ic_estudio, Category.PROFESION),

        IconItem("ic_dinero", "Dinero", R.drawable.ic_dinero, Category.DINERO),
        IconItem("ic_ahorro", "Ahorro / Banco", R.drawable.ic_ahorro, Category.DINERO),
        IconItem("ic_impuestos", "Impuestos", R.drawable.ic_impuestos, Category.DINERO),

        IconItem("ic_familia", "Familia", R.drawable.ic_familia, Category.FAMILIA),
        IconItem("ic_mascota", "Mascota", R.drawable.ic_mascota, Category.FAMILIA),
        IconItem("ic_comida", "Comida", R.drawable.ic_comida, Category.FAMILIA),
        IconItem("ic_limpieza", "Limpieza", R.drawable.ic_limpieza, Category.FAMILIA),

        IconItem("ic_iglesia", "Iglesia", R.drawable.ic_iglesia, Category.SERVICIO),

        IconItem("ic_lectura", "Lectura", R.drawable.ic_lectura, Category.RECREACION),
        IconItem("ic_escritura", "Escritura", R.drawable.ic_escritura, Category.RECREACION),
        IconItem("ic_avion", "Viaje", R.drawable.ic_avion, Category.RECREACION),

        IconItem("ic_telefono", "Llamada", R.drawable.ic_telefono, Category.RELACION),
        IconItem("ic_email", "Correo", R.drawable.ic_email, Category.RELACION),

        IconItem("ic_tarea", "Tarea genérica", R.drawable.ic_tarea, Category.OTRO),
        IconItem("ic_alarma", "Alarma", R.drawable.ic_alarma, Category.OTRO),
        IconItem("ic_generico", "Otro", R.drawable.ic_generico, Category.OTRO)
    )

    private val byKey = items.associateBy { it.key }

    fun resFor(key: String): Int = byKey[key]?.resId ?: R.drawable.ic_generico

    fun labelFor(key: String): String = byKey[key]?.label ?: "Icono"

    val defaultKey: String = "ic_tarea"
}
