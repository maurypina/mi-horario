package com.maury.horario.alarm

import android.content.BroadcastReceiver
import android.content.Context
import android.content.Intent
import com.maury.horario.HorarioApp
import com.maury.horario.data.LogStatus
import com.maury.horario.notification.NotificationHelper
import kotlinx.coroutines.launch
import java.time.LocalDate
import java.time.LocalDateTime

/**
 * Se dispara a la hora exacta de una tarea: muestra la notificación (con botones
 * Hecho/No hecho), crea el registro del día como PENDIENTE, y reprograma la
 * siguiente ocurrencia (semana o mes que viene).
 */
class AlarmReceiver : BroadcastReceiver() {

    override fun onReceive(context: Context, intent: Intent) {
        val taskId = intent.getLongExtra(EXTRA_TASK_ID, -1L)
        if (taskId < 0) return

        val app = context.applicationContext as HorarioApp
        val pendingResult = goAsync()

        app.appScope.launch {
            try {
                val task = app.database.taskDao().getById(taskId)
                if (task != null && task.active) {
                    NotificationHelper.showTaskNotification(context, task)
                    app.database.taskLogDao().upsert(
                        com.maury.horario.data.TaskLog(
                            taskId = task.id,
                            epochDay = LocalDate.now().toEpochDay(),
                            status = LogStatus.PENDING,
                            updatedAtEpochMillis = System.currentTimeMillis()
                        )
                    )
                    AlarmScheduler.scheduleNext(context, task, LocalDateTime.now().plusMinutes(1))
                }
            } finally {
                pendingResult.finish()
            }
        }
    }
}
