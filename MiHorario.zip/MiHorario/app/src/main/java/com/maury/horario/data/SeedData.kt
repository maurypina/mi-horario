package com.maury.horario.data

/**
 * Horario inicial precargado a partir del "Manifiesto" semanal que subiste.
 *
 * Los bloques con texto explícito en tu imagen (Venta GamingX 3h, Piña Producción,
 * Cobro publicidad, Fregar, Marketing, Suno, TukuToon, Iglesia, TSS día 3, DGII día 10)
 * se copiaron tal cual. Los bloques que solo tenían un icono (sin texto) se tradujeron
 * a un nombre razonable (ej. "Meditación", "Tiempo personal") — son una interpretación
 * y puedes renombrarlos/moverlos libremente tocando la tarea en la app.
 *
 * dayOfWeek: 1=Lunes .. 7=Domingo (ISO-8601)
 */
object SeedData {

    private fun w(
        title: String,
        category: Category,
        iconKey: String,
        dayOfWeek: Int,
        startHour: Int,
        endHour: Int,
        alarm: Boolean = true
    ) = Task(
        title = title,
        category = category,
        iconType = IconType.BUNDLED,
        iconKey = iconKey,
        recurrence = Recurrence.WEEKLY,
        dayOfWeek = dayOfWeek,
        startHour = startHour,
        endHour = endHour,
        alarmEnabled = alarm
    )

    private fun m(
        title: String,
        category: Category,
        iconKey: String,
        dayOfMonth: Int,
        startHour: Int,
        endHour: Int
    ) = Task(
        title = title,
        category = category,
        iconType = IconType.BUNDLED,
        iconKey = iconKey,
        recurrence = Recurrence.MONTHLY,
        dayOfMonth = dayOfMonth,
        startHour = startHour,
        endHour = endHour,
        alarmEnabled = true
    )

    fun build(): List<Task> {
        val tasks = mutableListOf<Task>()

        // ---------- LUNES ----------
        tasks += w("Ejercicio", Category.SALUD, "ic_ejercicio", 1, 5, 6)
        tasks += w("Meditación", Category.SALUD, "ic_meditacion", 1, 6, 7)
        tasks += w("Revisar tienda online", Category.PROFESION, "ic_tienda", 1, 7, 8)
        tasks += w("Desayuno y cuidado personal", Category.FAMILIA, "ic_comida", 1, 8, 9)
        tasks += w("Venta GamingX / Piña Producción (3h)", Category.PROFESION, "ic_tienda", 1, 9, 12)
        tasks += w("Tiempo personal / lectura", Category.RECREACION, "ic_lectura", 1, 12, 13)
        tasks += w("Almuerzo", Category.FAMILIA, "ic_comida", 1, 13, 14)
        tasks += w("Redes sociales / Marketing", Category.PROFESION, "ic_redes", 1, 14, 15)
        tasks += w("Cobro publicidad (Piña Producción)", Category.DINERO, "ic_dinero", 1, 15, 17)
        tasks += w("Tiempo personal", Category.RECREACION, "ic_lectura", 1, 17, 18)
        tasks += w("Revisar tienda", Category.PROFESION, "ic_tienda", 1, 18, 19)
        tasks += w("Alimentar mascota", Category.FAMILIA, "ic_mascota", 1, 19, 20)
        tasks += w("Cena", Category.FAMILIA, "ic_comida", 1, 20, 21)
        tasks += w("Descanso / dormir", Category.SALUD, "ic_descanso", 1, 21, 5, alarm = false)

        // ---------- MARTES ----------
        tasks += w("Meditación", Category.SALUD, "ic_meditacion", 2, 5, 7)
        tasks += w("Fregar / Limpieza", Category.FAMILIA, "ic_limpieza", 2, 7, 8)
        tasks += w("Edición de video", Category.PROFESION, "ic_video", 2, 8, 9)
        tasks += w("Venta GamingX / Piña Producción (3h)", Category.PROFESION, "ic_tienda", 2, 9, 12)
        tasks += w("Lectura", Category.RECREACION, "ic_lectura", 2, 12, 13)
        tasks += w("Almuerzo", Category.FAMILIA, "ic_comida", 2, 13, 14)
        tasks += w("Cobro publicidad (Piña Producción)", Category.DINERO, "ic_dinero", 2, 14, 15)
        tasks += w("Redes sociales / Marketing", Category.PROFESION, "ic_redes", 2, 15, 17)
        tasks += w("Tiempo personal", Category.RECREACION, "ic_lectura", 2, 17, 18)
        tasks += w("Revisar tienda", Category.PROFESION, "ic_tienda", 2, 18, 19)
        tasks += w("Alimentar mascota", Category.FAMILIA, "ic_mascota", 2, 19, 20)
        tasks += w("Cena", Category.FAMILIA, "ic_comida", 2, 20, 21)
        tasks += w("Descanso / dormir", Category.SALUD, "ic_descanso", 2, 21, 5, alarm = false)

        // ---------- MIÉRCOLES ----------
        tasks += w("Ejercicio", Category.SALUD, "ic_ejercicio", 3, 5, 6)
        tasks += w("Deporte (tenis/bádminton)", Category.SALUD, "ic_deporte", 3, 6, 8)
        tasks += w("Edición de video", Category.PROFESION, "ic_video", 3, 8, 9)
        tasks += w("Venta GamingX / Piña Producción (3h)", Category.PROFESION, "ic_tienda", 3, 9, 12)
        tasks += w("Escritura / Planificación", Category.RECREACION, "ic_escritura", 3, 12, 13)
        tasks += w("Almuerzo", Category.FAMILIA, "ic_comida", 3, 13, 14)
        tasks += w("Cobro publicidad (Piña Producción)", Category.DINERO, "ic_dinero", 3, 14, 15)
        tasks += w("Estudio / Marketing", Category.PROFESION, "ic_estudio", 3, 15, 17)
        tasks += w("Tiempo personal", Category.RECREACION, "ic_lectura", 3, 17, 18)
        tasks += w("Merienda", Category.FAMILIA, "ic_comida", 3, 18, 19)
        tasks += w("Alimentar mascota", Category.FAMILIA, "ic_mascota", 3, 19, 20)
        tasks += w("Cena", Category.FAMILIA, "ic_comida", 3, 20, 21)
        tasks += w("Descanso / dormir", Category.SALUD, "ic_descanso", 3, 21, 5, alarm = false)

        // ---------- JUEVES ----------
        tasks += w("Meditación", Category.SALUD, "ic_meditacion", 4, 5, 7)
        tasks += w("Fregar / Limpieza", Category.FAMILIA, "ic_limpieza", 4, 7, 8)
        tasks += w("Edición de video", Category.PROFESION, "ic_video", 4, 8, 9)
        tasks += w("Venta GamingX / Piña Producción (3h)", Category.PROFESION, "ic_tienda", 4, 9, 12)
        tasks += w("Lectura", Category.RECREACION, "ic_lectura", 4, 12, 13)
        tasks += w("Almuerzo", Category.FAMILIA, "ic_comida", 4, 13, 14)
        tasks += w("Cobro publicidad (Piña Producción)", Category.DINERO, "ic_dinero", 4, 14, 15)
        tasks += w("Redes sociales / Marketing", Category.PROFESION, "ic_redes", 4, 15, 17)
        tasks += w("Tiempo personal", Category.RECREACION, "ic_lectura", 4, 17, 18)
        tasks += w("Revisar tienda", Category.PROFESION, "ic_tienda", 4, 18, 19)
        tasks += w("Alimentar mascota", Category.FAMILIA, "ic_mascota", 4, 19, 20)
        tasks += w("Cena", Category.FAMILIA, "ic_comida", 4, 20, 21)
        tasks += w("Descanso / dormir", Category.SALUD, "ic_descanso", 4, 21, 5, alarm = false)

        // ---------- VIERNES ----------
        tasks += w("Ejercicio", Category.SALUD, "ic_ejercicio", 5, 5, 6)
        tasks += w("Deporte", Category.SALUD, "ic_deporte", 5, 6, 8)
        tasks += w("Edición de video", Category.PROFESION, "ic_video", 5, 8, 9)
        tasks += w("Ahorro / Banco", Category.DINERO, "ic_ahorro", 5, 9, 11)
        tasks += w("Escritura", Category.RECREACION, "ic_escritura", 5, 12, 13)
        tasks += w("Almuerzo", Category.FAMILIA, "ic_comida", 5, 13, 14)
        tasks += w("Cobro publicidad (Piña Producción)", Category.DINERO, "ic_dinero", 5, 14, 15)
        tasks += w("Redes sociales / Marketing", Category.PROFESION, "ic_redes", 5, 15, 17)
        tasks += w("Tiempo personal", Category.RECREACION, "ic_lectura", 5, 17, 18)
        tasks += w("Merienda", Category.FAMILIA, "ic_comida", 5, 18, 19)
        tasks += w("Alimentar mascota", Category.FAMILIA, "ic_mascota", 5, 19, 20)
        tasks += w("Cena", Category.FAMILIA, "ic_comida", 5, 20, 21)
        tasks += w("Descanso / dormir", Category.SALUD, "ic_descanso", 5, 21, 5, alarm = false)

        // ---------- SÁBADO ----------
        tasks += w("Fregar / Limpieza", Category.FAMILIA, "ic_limpieza", 6, 8, 9)
        tasks += w("Deporte (tenis)", Category.SALUD, "ic_deporte", 6, 9, 11)
        tasks += w("Producción musical (Suno)", Category.PROFESION, "ic_musica", 6, 12, 13)
        tasks += w("Tiempo libre", Category.RECREACION, "ic_lectura", 6, 13, 15)
        tasks += w("Estudio / Marketing", Category.PROFESION, "ic_estudio", 6, 15, 16)
        tasks += w("Escritura", Category.RECREACION, "ic_escritura", 6, 16, 17)
        tasks += w("Tiempo libre", Category.RECREACION, "ic_lectura", 6, 17, 19)
        tasks += w("Alimentar mascota", Category.FAMILIA, "ic_mascota", 6, 19, 20)
        tasks += w("Descanso / dormir", Category.SALUD, "ic_descanso", 6, 21, 8, alarm = false)

        // ---------- DOMINGO ----------
        tasks += w("Desayuno en familia", Category.FAMILIA, "ic_comida", 7, 8, 9)
        tasks += w("Tiempo en familia", Category.FAMILIA, "ic_familia", 7, 9, 12)
        tasks += w("Almuerzo", Category.FAMILIA, "ic_comida", 7, 13, 14)
        tasks += w("Iglesia", Category.SERVICIO, "ic_iglesia", 7, 18, 19)
        tasks += w("TukuToon (contenido infantil)", Category.RECREACION, "ic_video", 7, 18, 19)
        tasks += w("Cena en familia", Category.FAMILIA, "ic_comida", 7, 19, 20)
        tasks += w("Descanso / dormir", Category.SALUD, "ic_descanso", 7, 21, 8, alarm = false)

        // ---------- MENSUALES ----------
        tasks += m("TSS", Category.DINERO, "ic_impuestos", 3, 9, 10)
        tasks += m("DGII", Category.DINERO, "ic_impuestos", 10, 9, 10)

        return tasks
    }
}
