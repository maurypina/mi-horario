package com.maury.horario.data

import androidx.room.Dao
import androidx.room.Insert
import androidx.room.OnConflictStrategy
import androidx.room.Query
import androidx.room.Update
import kotlinx.coroutines.flow.Flow

@Dao
interface TaskLogDao {

    @Query("SELECT * FROM task_logs WHERE epochDay = :epochDay")
    fun observeForDay(epochDay: Long): Flow<List<TaskLog>>

    @Query("SELECT * FROM task_logs WHERE taskId = :taskId AND epochDay = :epochDay LIMIT 1")
    suspend fun findLog(taskId: Long, epochDay: Long): TaskLog?

    @Query("SELECT * FROM task_logs WHERE epochDay BETWEEN :fromDay AND :toDay")
    fun observeRange(fromDay: Long, toDay: Long): Flow<List<TaskLog>>

    @Insert(onConflict = OnConflictStrategy.REPLACE)
    suspend fun upsert(log: TaskLog): Long

    @Update
    suspend fun update(log: TaskLog)

    @Query("SELECT COUNT(*) FROM task_logs WHERE taskId = :taskId AND status = 'DONE'")
    suspend fun countDoneForTask(taskId: Long): Int

    @Query("DELETE FROM task_logs WHERE taskId = :taskId")
    suspend fun deleteForTask(taskId: Long)
}
