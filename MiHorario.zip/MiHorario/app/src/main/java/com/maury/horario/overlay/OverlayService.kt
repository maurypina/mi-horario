package com.maury.horario.overlay

import android.app.NotificationManager
import android.app.PendingIntent
import android.app.Service
import android.content.Context
import android.content.Intent
import android.graphics.PixelFormat
import android.os.Build
import android.os.IBinder
import android.view.Gravity
import android.view.LayoutInflater
import android.view.MotionEvent
import android.view.View
import android.view.WindowManager
import android.widget.ImageView
import android.widget.LinearLayout
import android.widget.TextView
import androidx.core.app.NotificationCompat
import com.maury.horario.HorarioApp
import com.maury.horario.MainActivity
import com.maury.horario.R
import com.maury.horario.data.LogStatus
import com.maury.horario.notification.CHANNEL_ID
import com.maury.horario.ui.icons.IconCatalog
import com.maury.horario.util.DateUtils
import kotlinx.coroutines.CoroutineScope
import kotlinx.coroutines.Job
import kotlinx.coroutines.launch
import java.time.LocalDate
import kotlin.math.abs

/**
 * Muestra una burbuja flotante (como los "chat heads") con la tarea actual.
 * Al tocarla se expande un panel con las tareas pendientes de hoy, donde puedes
 * marcarlas como hechas o no hechas sin abrir la app.
 */
class OverlayService : Service() {

    private lateinit var windowManager: WindowManager
    private var bubbleView: View? = null
    private var panelView: View? = null
    private var bubbleParams: WindowManager.LayoutParams? = null
    private val job = Job()
    private val scope = CoroutineScope(job)

    override fun onBind(intent: Intent?): IBinder? = null

    override fun onCreate() {
        super.onCreate()
        windowManager = getSystemService(Context.WINDOW_SERVICE) as WindowManager
        startForeground(FOREGROUND_ID, buildForegroundNotification())
        addBubble()
    }

    override fun onStartCommand(intent: Intent?, flags: Int, startId: Int): Int {
        return START_STICKY
    }

    private fun buildForegroundNotification(): android.app.Notification {
        val openApp = PendingIntent.getActivity(
            this, 0, Intent(this, MainActivity::class.java),
            PendingIntent.FLAG_UPDATE_CURRENT or PendingIntent.FLAG_IMMUTABLE
        )
        return NotificationCompat.Builder(this, CHANNEL_ID)
            .setSmallIcon(R.drawable.ic_alarma)
            .setContentTitle("Mi Horario activo")
            .setContentText("La burbuja flotante está mostrando tus tareas del día.")
            .setPriority(NotificationCompat.PRIORITY_LOW)
            .setOngoing(true)
            .setContentIntent(openApp)
            .build()
    }

    private fun windowType() =
        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.O)
            WindowManager.LayoutParams.TYPE_APPLICATION_OVERLAY
        else
            @Suppress("DEPRECATION") WindowManager.LayoutParams.TYPE_PHONE

    private fun addBubble() {
        val inflater = LayoutInflater.from(this)
        val view = inflater.inflate(R.layout.overlay_bubble, null)
        bubbleView = view

        val params = WindowManager.LayoutParams(
            WindowManager.LayoutParams.WRAP_CONTENT,
            WindowManager.LayoutParams.WRAP_CONTENT,
            windowType(),
            WindowManager.LayoutParams.FLAG_NOT_FOCUSABLE,
            PixelFormat.TRANSLUCENT
        ).apply {
            gravity = Gravity.TOP or Gravity.START
            x = 0
            y = 300
        }
        bubbleParams = params
        windowManager.addView(view, params)
        applyCurrentTaskIcon(view)
        attachDragBehavior(view, params)
    }

    private fun applyCurrentTaskIcon(bubble: View) {
        scope.launch {
            val app = applicationContext as HorarioApp
            val now = java.time.LocalDateTime.now()
            val today = DateUtils.tasksForDate(app.database.taskDao().getAllOnce(), now.toLocalDate())
            val current = today.firstOrNull { inRange(it.startHour, it.endHour, now.hour) }
            val icon = bubble.findViewById<ImageView>(R.id.bubbleIcon)
            icon.setImageResource(
                if (current != null) IconCatalog.resFor(current.iconKey) else R.drawable.ic_tarea
            )
        }
    }

    private fun inRange(start: Int, end: Int, hour: Int): Boolean =
        if (start <= end) hour in start until end else hour >= start || hour < end

    private fun attachDragBehavior(view: View, params: WindowManager.LayoutParams) {
        var initialX = 0
        var initialY = 0
        var touchX = 0f
        var touchY = 0f
        var moved = false

        view.setOnTouchListener { _, event ->
            when (event.action) {
                MotionEvent.ACTION_DOWN -> {
                    initialX = params.x
                    initialY = params.y
                    touchX = event.rawX
                    touchY = event.rawY
                    moved = false
                    true
                }
                MotionEvent.ACTION_MOVE -> {
                    val dx = (event.rawX - touchX).toInt()
                    val dy = (event.rawY - touchY).toInt()
                    if (abs(dx) > 8 || abs(dy) > 8) moved = true
                    params.x = initialX + dx
                    params.y = initialY + dy
                    windowManager.updateViewLayout(view, params)
                    true
                }
                MotionEvent.ACTION_UP -> {
                    if (!moved) toggleExpand()
                    true
                }
                else -> false
            }
        }
    }

    private fun toggleExpand() {
        if (panelView != null) collapsePanel() else expandPanel()
    }

    private fun expandPanel() {
        val inflater = LayoutInflater.from(this)
        val view = inflater.inflate(R.layout.overlay_panel, null)
        panelView = view

        val params = WindowManager.LayoutParams(
            WindowManager.LayoutParams.WRAP_CONTENT,
            WindowManager.LayoutParams.WRAP_CONTENT,
            windowType(),
            WindowManager.LayoutParams.FLAG_NOT_FOCUSABLE,
            PixelFormat.TRANSLUCENT
        ).apply {
            gravity = Gravity.TOP or Gravity.START
            x = (bubbleParams?.x ?: 0)
            y = (bubbleParams?.y ?: 300) + 70
        }
        windowManager.addView(view, params)

        view.findViewById<TextView>(R.id.panelClose).setOnClickListener { collapsePanel() }
        view.findViewById<TextView>(R.id.panelOpenApp).setOnClickListener {
            val i = Intent(this, MainActivity::class.java).addFlags(Intent.FLAG_ACTIVITY_NEW_TASK)
            startActivity(i)
            collapsePanel()
        }
        populateTasks(view)
    }

    private fun populateTasks(panel: View) {
        scope.launch {
            val app = applicationContext as HorarioApp
            val today = LocalDate.now()
            val allTasks = app.database.taskDao().getAllOnce()
            val todayTasks = DateUtils.tasksForDate(allTasks, today).sortedBy { it.startHour }
            val list = panel.findViewById<LinearLayout>(R.id.panelTaskList)
            list.removeAllViews()

            if (todayTasks.isEmpty()) {
                val empty = TextView(this@OverlayService)
                empty.text = "No hay tareas para hoy"
                empty.textSize = 13f
                list.addView(empty)
                return@launch
            }

            val inflater = LayoutInflater.from(this@OverlayService)
            todayTasks.forEach { task ->
                val row = inflater.inflate(R.layout.overlay_task_row, list, false)
                row.findViewById<ImageView>(R.id.rowIcon).setImageResource(IconCatalog.resFor(task.iconKey))
                row.findViewById<TextView>(R.id.rowTitle).text =
                    String.format("%02d:00 %s", task.startHour, task.title)
                row.findViewById<TextView>(R.id.rowDone).setOnClickListener {
                    scope.launch {
                        app.database.taskLogDao().upsert(
                            com.maury.horario.data.TaskLog(
                                taskId = task.id,
                                epochDay = today.toEpochDay(),
                                status = LogStatus.DONE,
                                updatedAtEpochMillis = System.currentTimeMillis()
                            )
                        )
                    }
                    list.removeView(row)
                }
                row.findViewById<TextView>(R.id.rowMissed).setOnClickListener {
                    scope.launch {
                        app.database.taskLogDao().upsert(
                            com.maury.horario.data.TaskLog(
                                taskId = task.id,
                                epochDay = today.toEpochDay(),
                                status = LogStatus.MISSED,
                                updatedAtEpochMillis = System.currentTimeMillis()
                            )
                        )
                    }
                    list.removeView(row)
                }
                list.addView(row)
            }
        }
    }

    private fun collapsePanel() {
        panelView?.let { runCatching { windowManager.removeView(it) } }
        panelView = null
    }

    override fun onDestroy() {
        super.onDestroy()
        job.cancel()
        collapsePanel()
        bubbleView?.let { runCatching { windowManager.removeView(it) } }
        bubbleView = null
    }

    companion object {
        private const val FOREGROUND_ID = 9001

        fun start(context: Context) {
            val intent = Intent(context, OverlayService::class.java)
            if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.O) {
                context.startForegroundService(intent)
            } else {
                context.startService(intent)
            }
        }

        fun stop(context: Context) {
            context.stopService(Intent(context, OverlayService::class.java))
        }
    }
}
