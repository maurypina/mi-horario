package com.maury.horario.alarm

import android.content.BroadcastReceiver
import android.content.Context
import android.content.Intent
import com.maury.horario.HorarioApp
import kotlinx.coroutines.launch

/**
 * Las alarmas exactas de Android se borran al reiniciar el celular, así que
 * las reprogramamos todas apenas el sistema termina de arrancar.
 */
class BootReceiver : BroadcastReceiver() {
    override fun onReceive(context: Context, intent: Intent) {
        if (intent.action != Intent.ACTION_BOOT_COMPLETED &&
            intent.action != Intent.ACTION_MY_PACKAGE_REPLACED
        ) return

        val app = context.applicationContext as HorarioApp
        val pendingResult = goAsync()
        app.appScope.launch {
            try {
                app.database.taskDao().getAllOnce()
                    .filter { it.alarmEnabled }
                    .forEach { task -> AlarmScheduler.scheduleNext(context, task) }
            } finally {
                pendingResult.finish()
            }
        }
    }
}
