package com.maury.horario

import android.Manifest
import android.os.Build
import android.os.Bundle
import androidx.activity.ComponentActivity
import androidx.activity.compose.setContent
import androidx.activity.compose.rememberLauncherForActivityResult
import androidx.activity.result.contract.ActivityResultContracts
import androidx.activity.viewModels
import androidx.compose.foundation.layout.padding
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.CalendarViewWeek
import androidx.compose.material.icons.filled.CheckCircle
import androidx.compose.material.icons.filled.Settings
import androidx.compose.material.icons.filled.Today
import androidx.compose.material3.Icon
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.NavigationBar
import androidx.compose.material3.NavigationBarItem
import androidx.compose.material3.Scaffold
import androidx.compose.material3.Surface
import androidx.compose.material3.Text
import androidx.compose.runtime.getValue
import androidx.compose.ui.Modifier
import androidx.navigation.NavGraph.Companion.findStartDestination
import androidx.navigation.compose.NavHost
import androidx.navigation.compose.composable
import androidx.navigation.compose.currentBackStackEntryAsState
import androidx.navigation.compose.rememberNavController
import com.maury.horario.ui.HorarioViewModel
import com.maury.horario.ui.editor.EditorScreen
import com.maury.horario.ui.history.HistoryScreen
import com.maury.horario.ui.icons.IconPickerScreen
import com.maury.horario.ui.settings.SettingsScreen
import com.maury.horario.ui.theme.MiHorarioTheme
import com.maury.horario.ui.today.TodayScreen
import com.maury.horario.ui.week.WeekScreen

private data class BottomDest(val route: String, val label: String, val icon: androidx.compose.ui.graphics.vector.ImageVector)

private val bottomDestinations = listOf(
    BottomDest("hoy", "Hoy", Icons.Filled.Today),
    BottomDest("semana", "Semana", Icons.Filled.CalendarViewWeek),
    BottomDest("historial", "Historial", Icons.Filled.CheckCircle),
    BottomDest("ajustes", "Ajustes", Icons.Filled.Settings)
)

class MainActivity : ComponentActivity() {

    private val viewModel: HorarioViewModel by viewModels()

    private val requestNotifPermission = registerForActivityResult(
        ActivityResultContracts.RequestPermission()
    ) { /* no-op: si se niega, simplemente no habrá notificaciones visibles */ }

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)

        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.TIRAMISU) {
            requestNotifPermission.launch(Manifest.permission.POST_NOTIFICATIONS)
        }

        setContent {
            MiHorarioTheme {
                Surface(color = MaterialTheme.colorScheme.background) {
                    AppScaffold(viewModel)
                }
            }
        }
    }
}

@androidx.compose.runtime.Composable
private fun AppScaffold(viewModel: HorarioViewModel) {
    val navController = rememberNavController()
    val backStackEntry by navController.currentBackStackEntryAsState()
    val currentRoute = backStackEntry?.destination?.route
    val showBottomBar = bottomDestinations.any { it.route == currentRoute }

    Scaffold(
        bottomBar = {
            if (showBottomBar) {
                NavigationBar {
                    bottomDestinations.forEach { dest ->
                        NavigationBarItem(
                            selected = currentRoute == dest.route,
                            onClick = {
                                navController.navigate(dest.route) {
                                    popUpTo(navController.graph.findStartDestination().id) { saveState = true }
                                    launchSingleTop = true
                                    restoreState = true
                                }
                            },
                            icon = { Icon(dest.icon, contentDescription = dest.label) },
                            label = { Text(dest.label) }
                        )
                    }
                }
            }
        }
    ) { padding ->
        NavHost(
            navController = navController,
            startDestination = "hoy",
            modifier = Modifier.padding(padding)
        ) {
            composable("hoy") {
                TodayScreen(
                    viewModel = viewModel,
                    onAddTask = {
                        viewModel.startNewDraft()
                        navController.navigate("editor")
                    },
                    onEditTask = { task ->
                        viewModel.startEditDraft(task)
                        navController.navigate("editor")
                    }
                )
            }
            composable("semana") {
                WeekScreen(
                    viewModel = viewModel,
                    onAddTask = { dayOfWeek ->
                        if (dayOfWeek != null) {
                            viewModel.startNewDraft(dayOfWeek = dayOfWeek)
                        } else {
                            viewModel.startNewDraft(dayOfMonth = 1)
                        }
                        navController.navigate("editor")
                    },
                    onEditTask = { task ->
                        viewModel.startEditDraft(task)
                        navController.navigate("editor")
                    }
                )
            }
            composable("historial") {
                HistoryScreen(viewModel = viewModel)
            }
            composable("ajustes") {
                SettingsScreen()
            }
            composable("editor") {
                EditorScreen(
                    viewModel = viewModel,
                    onDone = { navController.popBackStack() },
                    onPickIcon = { navController.navigate("icon_picker") }
                )
            }
            composable("icon_picker") {
                IconPickerScreen(
                    viewModel = viewModel,
                    onDone = { navController.popBackStack() }
                )
            }
        }
    }
}
