package com.maury.horario.ui.today

import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.Add
import androidx.compose.material.icons.filled.ChevronLeft
import androidx.compose.material.icons.filled.ChevronRight
import androidx.compose.material3.Button
import androidx.compose.material3.Card
import androidx.compose.material3.FloatingActionButton
import androidx.compose.material3.Icon
import androidx.compose.material3.IconButton
import androidx.compose.material3.Scaffold
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.res.painterResource
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.lifecycle.compose.collectAsStateWithLifecycle
import com.maury.horario.data.Category
import com.maury.horario.data.IconType
import com.maury.horario.data.LogStatus
import com.maury.horario.data.Task
import com.maury.horario.data.TaskLog
import com.maury.horario.ui.HorarioViewModel
import com.maury.horario.ui.icons.IconCatalog
import com.maury.horario.util.DateUtils
import java.time.LocalDate
import java.time.format.DateTimeFormatter
import java.util.Locale

@Composable
fun TodayScreen(
    viewModel: HorarioViewModel,
    onAddTask: () -> Unit,
    onEditTask: (Task) -> Unit
) {
    var selectedDate by remember { mutableStateOf(LocalDate.now()) }
    val allTasks by viewModel.tasks.collectAsStateWithLifecycle()
    val logs by viewModel.logsForDate(selectedDate).collectAsStateWithLifecycle(initialValue = emptyList())

    val tasksForDay = remember(allTasks, selectedDate) {
        DateUtils.tasksForDate(allTasks, selectedDate).sortedBy { it.startHour }
    }
    val logsByTaskId = remember(logs) { logs.associateBy { it.taskId } }

    Scaffold(
        floatingActionButton = {
            FloatingActionButton(onClick = onAddTask) {
                Icon(Icons.Filled.Add, contentDescription = "Agregar tarea")
            }
        }
    ) { padding ->
        Column(modifier = Modifier.fillMaxSize().padding(padding)) {
            DateHeader(
                date = selectedDate,
                onPrev = { selectedDate = selectedDate.minusDays(1) },
                onNext = { selectedDate = selectedDate.plusDays(1) },
                onToday = { selectedDate = LocalDate.now() }
            )

            if (tasksForDay.isEmpty()) {
                Box(modifier = Modifier.fillMaxSize(), contentAlignment = Alignment.Center) {
                    Text("No tienes tareas este día. Toca + para agregar una.")
                }
            } else {
                LazyColumn(modifier = Modifier.fillMaxSize().padding(horizontal = 12.dp)) {
                    items(tasksForDay, key = { it.id }) { task ->
                        TaskRow(
                            task = task,
                            status = logsByTaskId[task.id]?.status ?: LogStatus.PENDING,
                            onClick = { onEditTask(task) },
                            onSetStatus = { status -> viewModel.setStatus(task.id, selectedDate, status) }
                        )
                    }
                }
            }
        }
    }
}

@Composable
private fun DateHeader(date: LocalDate, onPrev: () -> Unit, onNext: () -> Unit, onToday: () -> Unit) {
    Row(
        modifier = Modifier.fillMaxWidth().padding(8.dp),
        horizontalArrangement = Arrangement.SpaceBetween,
        verticalAlignment = Alignment.CenterVertically
    ) {
        IconButton(onClick = onPrev) { Icon(Icons.Filled.ChevronLeft, contentDescription = "Día anterior") }
        val formatter = DateTimeFormatter.ofPattern("EEEE d 'de' MMMM", Locale("es", "ES"))
        Text(
            text = date.format(formatter).replaceFirstChar { it.uppercase() },
            fontWeight = FontWeight.Bold,
            modifier = Modifier.padding(horizontal = 4.dp)
        )
        IconButton(onClick = onNext) { Icon(Icons.Filled.ChevronRight, contentDescription = "Día siguiente") }
    }
    if (date != LocalDate.now()) {
        Row(modifier = Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.Center) {
            Button(onClick = onToday) { Text("Ir a hoy") }
        }
    }
}

@Composable
fun TaskRow(
    task: Task,
    status: LogStatus,
    onClick: () -> Unit,
    onSetStatus: (LogStatus) -> Unit
) {
    Card(
        modifier = Modifier
            .fillMaxWidth()
            .padding(vertical = 4.dp),
        onClick = onClick
    ) {
        Row(
            modifier = Modifier.fillMaxWidth().padding(10.dp),
            verticalAlignment = Alignment.CenterVertically
        ) {
            TaskIcon(task)
            Column(modifier = Modifier.padding(start = 10.dp).weight(1f)) {
                Text(
                    text = String.format("%02d:00 - %02d:00", task.startHour, task.endHour),
                    fontWeight = FontWeight.Medium
                )
                Text(text = task.title)
                Text(text = task.category.etiqueta, style = androidx.compose.material3.MaterialTheme.typography.labelSmall)
            }
            StatusButtons(status = status, onSetStatus = onSetStatus)
        }
    }
}

@Composable
fun TaskIcon(task: Task) {
    Box(modifier = Modifier.size(40.dp), contentAlignment = Alignment.Center) {
        if (task.iconType == IconType.CUSTOM) {
            com.maury.horario.ui.icons.CustomIconImage(uriString = task.iconKey, modifier = Modifier.size(36.dp))
        } else {
            Icon(
                painter = painterResource(id = IconCatalog.resFor(task.iconKey)),
                contentDescription = task.title,
                modifier = Modifier.size(28.dp)
            )
        }
    }
}

@Composable
private fun StatusButtons(status: LogStatus, onSetStatus: (LogStatus) -> Unit) {
    Row {
        IconButton(onClick = { onSetStatus(LogStatus.DONE) }) {
            Text(if (status == LogStatus.DONE) "✅" else "⬜")
        }
        IconButton(onClick = { onSetStatus(LogStatus.MISSED) }) {
            Text(if (status == LogStatus.MISSED) "❌" else "⬜")
        }
    }
}
