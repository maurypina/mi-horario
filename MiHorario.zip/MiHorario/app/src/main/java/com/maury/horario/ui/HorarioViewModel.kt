package com.maury.horario.ui

import android.app.Application
import androidx.lifecycle.AndroidViewModel
import androidx.lifecycle.viewModelScope
import com.maury.horario.HorarioApp
import com.maury.horario.data.Category
import com.maury.horario.data.IconType
import com.maury.horario.data.LogStatus
import com.maury.horario.data.Recurrence
import com.maury.horario.data.Task
import com.maury.horario.data.TaskLog
import com.maury.horario.data.TaskRepository
import com.maury.horario.ui.icons.IconCatalog
import kotlinx.coroutines.flow.Flow
import kotlinx.coroutines.flow.MutableStateFlow
import kotlinx.coroutines.flow.SharingStarted
import kotlinx.coroutines.flow.StateFlow
import kotlinx.coroutines.flow.stateIn
import kotlinx.coroutines.launch
import java.time.LocalDate

data class TaskDraft(
    val id: Long = 0,
    val title: String = "",
    val category: Category = Category.OTRO,
    val iconType: IconType = IconType.BUNDLED,
    val iconKey: String = IconCatalog.defaultKey,
    val recurrence: Recurrence = Recurrence.WEEKLY,
    val dayOfWeek: Int = 1,
    val dayOfMonth: Int = 1,
    val startHour: Int = 8,
    val endHour: Int = 9,
    val alarmEnabled: Boolean = true
) {
    fun toTask(): Task = Task(
        id = id,
        title = title.ifBlank { "Tarea sin nombre" },
        category = category,
        iconType = iconType,
        iconKey = iconKey,
        recurrence = recurrence,
        dayOfWeek = if (recurrence == Recurrence.WEEKLY) dayOfWeek else null,
        dayOfMonth = if (recurrence == Recurrence.MONTHLY) dayOfMonth else null,
        startHour = startHour,
        endHour = endHour,
        alarmEnabled = alarmEnabled
    )

    companion object {
        fun fromTask(t: Task): TaskDraft = TaskDraft(
            id = t.id,
            title = t.title,
            category = t.category,
            iconType = t.iconType,
            iconKey = t.iconKey,
            recurrence = t.recurrence,
            dayOfWeek = t.dayOfWeek ?: 1,
            dayOfMonth = t.dayOfMonth ?: 1,
            startHour = t.startHour,
            endHour = t.endHour,
            alarmEnabled = t.alarmEnabled
        )
    }
}

class HorarioViewModel(application: Application) : AndroidViewModel(application) {

    private val repo: TaskRepository by lazy {
        val app = getApplication<HorarioApp>()
        TaskRepository(app, app.database.taskDao(), app.database.taskLogDao())
    }

    val tasks: StateFlow<List<Task>> by lazy {
        repo.observeAllTasks().stateIn(viewModelScope, SharingStarted.WhileSubscribed(5000), emptyList())
    }

    private val _draft = MutableStateFlow(TaskDraft())
    val draft: StateFlow<TaskDraft> = _draft

    fun startNewDraft(dayOfWeek: Int? = null, dayOfMonth: Int? = null) {
        _draft.value = TaskDraft(
            recurrence = if (dayOfMonth != null) Recurrence.MONTHLY else Recurrence.WEEKLY,
            dayOfWeek = dayOfWeek ?: 1,
            dayOfMonth = dayOfMonth ?: 1
        )
    }

    fun startEditDraft(task: Task) {
        _draft.value = TaskDraft.fromTask(task)
    }

    fun updateDraft(transform: (TaskDraft) -> TaskDraft) {
        _draft.value = transform(_draft.value)
    }

    fun saveDraft(onSaved: () -> Unit) {
        viewModelScope.launch {
            repo.saveTask(_draft.value.toTask())
            onSaved()
        }
    }

    fun deleteTask(task: Task, onDeleted: () -> Unit = {}) {
        viewModelScope.launch {
            repo.deleteTask(task)
            onDeleted()
        }
    }

    fun setStatus(taskId: Long, date: LocalDate, status: LogStatus) {
        viewModelScope.launch { repo.setStatus(taskId, date, status) }
    }

    fun logsForDate(date: LocalDate): Flow<List<TaskLog>> = repo.observeLogsForDay(date)

    fun logsRange(from: LocalDate, to: LocalDate): Flow<List<TaskLog>> = repo.observeLogsRange(from, to)
}
