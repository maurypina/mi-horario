# Mi Horario

App Android nativa (Kotlin + Jetpack Compose) para tu horario diario/semanal/mensual,
con alarmas, notificaciones con botones "Hecho ✅ / No hecho ❌", burbuja flotante estilo
Facebook Messenger sobre otras apps, selector de iconos (galería incluida + tus propias
fotos) y registro/historial de cumplimiento.

Viene precargada con el horario de tu "Manifiesto" (Lunes a Domingo, más TSS día 3 y
DGII día 10). **Los bloques que en tu imagen solo tenían un icono (sin texto) se
tradujeron a un nombre razonable** (ej. el icono de loto → "Meditación"). Revísalos y
renómbralos/muévelos libremente tocando cualquier tarea — es solo el punto de partida.

## Cómo obtener el APK instalable en tu Samsung S23

Este proyecto **no se pudo compilar dentro del entorno de este chat** porque ese entorno
en la nube tiene bloqueado el acceso a los servidores de Google/Gradle donde se descargan
las herramientas de compilación de Android (por seguridad). Por eso te entrego el
proyecto completo y ya listo, con dos formas de conseguir el APK, ambas gratis:

### Opción A — Recomendada: que GitHub lo compile por ti (no requiere instalar nada)

1. Crea una cuenta gratis en [github.com](https://github.com) si no tienes una.
2. Crea un repositorio nuevo (puede ser privado), por ejemplo `mi-horario`.
3. Sube este proyecto tal cual lo descomprimiste (todos los archivos y carpetas) a ese
   repositorio. Puedes arrastrar la carpeta completa en la interfaz web de GitHub
   ("Add file" → "Upload files"), o si usas git:
   ```
   cd MiHorario
   git init
   git add .
   git commit -m "Mi Horario"
   git branch -M main
   git remote add origin https://github.com/TU_USUARIO/mi-horario.git
   git push -u origin main
   ```
4. Entra a la pestaña **Actions** de tu repositorio en GitHub. Automáticamente empezará
   a correr "Compilar APK" (tarda 2-4 minutos la primera vez).
5. Cuando termine (ícono verde ✅), entra a esa ejecución y baja hasta "Artifacts":
   ahí está `MiHorario-debug-apk` para descargar. También queda publicado en la sección
   **Releases** del repositorio como `app-debug.apk`, que es más fácil de abrir desde el
   navegador del celular.
6. Descarga el APK directamente desde tu Samsung S23 (Chrome), ábrelo, y si Android te
   pide permiso para "instalar apps de fuentes desconocidas", actívalo solo para esa
   descarga. Instala.

Cada vez que quieras cambiar algo del código y quieras un nuevo APK, solo sube los
cambios (`git push`) y GitHub genera uno nuevo automáticamente.

### Opción B — Compilarlo tú con Android Studio (si tienes una PC/Mac)

1. Instala [Android Studio](https://developer.android.com/studio) (gratis).
2. Abre este proyecto (`File → Open`, selecciona la carpeta `MiHorario`).
3. Espera a que Android Studio descargue automáticamente todo lo necesario (SDK,
   Gradle, etc. — esto sí funciona porque Android Studio en tu computadora tiene
   internet normal, sin las restricciones del entorno donde se creó este proyecto).
4. Conecta tu Samsung S23 por USB con la depuración USB activada, y presiona el botón
   ▶ Run. O genera el APK con `Build → Build Bundle(s) / APK(s) → Build APK(s)`.

## Primeros pasos al abrir la app por primera vez

1. Acepta el permiso de notificaciones cuando te lo pida.
2. Ve a la pestaña **Ajustes** y concede:
   - **Permitir burbuja flotante** (para ver la tarea actual sobre otras apps).
   - **Permitir alarmas exactas** (para que suenen justo a la hora, sin retraso).
3. Desde Ajustes puedes **Iniciar burbuja flotante** cuando quieras verla activa.
4. En **Semana** puedes editar tu horario recurrente (por día, o "Mensual" para TSS/DGII).
5. En **Hoy** marcas cada tarea como hecha ✅ o no hecha ❌, y ahí también llegan las
   alarmas con esos mismos botones directo en la notificación.
6. En **Historial** ves tu cumplimiento de los últimos 14 días y el balance entre las
   áreas de tu Manifiesto (Dinero, Relación, Recreación, Familia, Salud, Servicio
   comunitario, Profesión).
7. Al crear o editar una tarea, toca "Elegir icono" para usar uno de los ~30 incluidos,
   o "Elegir una imagen de mi galería" para poner una foto/icono tuyo personalizado.

## Notas técnicas

- Kotlin + Jetpack Compose + Room (base de datos local) + AlarmManager + un Foreground
  Service con `WindowManager` para la burbuja flotante.
- `minSdk 26` (Android 8.0+), compatible con tu Samsung S23.
- Todo el horario y el historial se guardan localmente en el celular (no se sube a
  ningún servidor).
- Si al compilar en GitHub Actions ves un error (poco probable, pero puede pasar con
  versiones de librerías), copia el mensaje de error de la pestaña Actions y compártelo
  para ayudarte a corregirlo.
